function printTable(array) {
    array.forEach(function (item) {
        console.log(item);
    })
}

printTable([1, 2, 3, 4, 5]);
printTable(['Jeden', 'Dwa', 'Trzy']);