function distFromAverage(array) {
    const arrayLength = array.length;
    const arraySum = array.reduce(function (total, item) {
        return total + item;
    });
    const arrayAverage = arraySum / arrayLength;

    // v1 - .forEach()
    // const resultArray = [];
    // array.forEach(function (item, index, array) {
    //     resultArray.push(Math.abs(item - arrayAverage))
    // });

    // v2 - .map()
    const resultArray = array.map(function (item, index, array) {
        return Math.abs(item - arrayAverage);
    })

    return resultArray;
}

console.log(distFromAverage([1, 2, 3, 4, 5, 6, 7]));
