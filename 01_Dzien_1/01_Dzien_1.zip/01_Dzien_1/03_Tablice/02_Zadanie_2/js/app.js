const fruits = ['Apple', 'Mango', 'Banana', 'Kiwi'];

console.log(fruits[0]);
console.log(fruits[fruits.length - 1]);

for (let i = 0; i < fruits.length; i++) {
    console.log(fruits[i]);
}