![Coders-Lab-1920px-no-background](https://user-images.githubusercontent.com/30623667/104709394-2cabee80-571f-11eb-9518-ea6a794e558e.png)


## Zadanie 1 - rozwiązywane z wykładowcą

Przetestuj działanie `setTimeout` i `setInterval`. 

Uruchom interwał, który co `10s` będzie wyświetlał napis "Wygenerowano z setInterval" w konsoli. A także timer, który po `4s` wypisze w konsoli: "JavaScript Rules".



## Zadanie 2

Napisz funkcję `countHello()`, która jako parametr przyjmie liczbę całkowitą od 1 do 10. W funkcji uruchom funkcję `setInterval`. 

Jego zadaniem będzie wypisywanie na konsoli tekstu "Hello" oraz licznika, zliczającego, który raz już został uruchomiony `setInterval`.
Jeśli licznik osiągnie wartość podaną do funkcji jako parametr, powinien zostać usunięty `setInterval`.

