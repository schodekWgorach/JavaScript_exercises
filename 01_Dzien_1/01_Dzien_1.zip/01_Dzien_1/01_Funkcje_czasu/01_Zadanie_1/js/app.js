setInterval(function () {
  console.log("Wygenerowano z setInterval");
}, 1000);

setTimeout(function () {
  console.log("JavaScript rules");
}, 4000);
