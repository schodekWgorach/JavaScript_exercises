function countHello(iterator) {
    let counter = 1;
    const intervalID = setInterval(function () {
        if (counter > iterator) {
            clearInterval(intervalID);
        } else {
            console.log('Hello ' + counter);
            counter++;
        }
    }, 1000);
}

countHello(8);
