firstFunc();

function firstFunc() {
    console.log('Pierwsza funkcja');
}

firstFunc();

secondFunc();

const secondFunc = function () {
    console.log('Druga funkcja');
}

secondFunc();