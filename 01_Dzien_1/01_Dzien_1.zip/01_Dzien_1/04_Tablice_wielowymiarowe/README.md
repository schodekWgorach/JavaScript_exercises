![Coders-Lab-1920px-no-background](https://user-images.githubusercontent.com/30623667/104709394-2cabee80-571f-11eb-9518-ea6a794e558e.png)


## Zadanie 1

W pliku `js/app.js` znajduje się tablica o nazwie `multiValueArray`. 

1. Wypisz element znajdujący się w położeniu `3`, `2`.
1. Wypisz długość tablicy znajdującej się w drugim rzędzie.
1. Wypisz element znajdujący się w położeniu `4`, `2`.



## Zadanie 2

Napisz funkcje `print2DArray`, która będzie przyjmować  jako argument tablicę dwuwymiarową. Następnie funkcja ma wypisać w konsoli zawartość tej tablicy.

